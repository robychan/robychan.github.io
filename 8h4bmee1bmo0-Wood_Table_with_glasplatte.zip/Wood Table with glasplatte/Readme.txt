A small radio which stands in my room on the cabinet. The antenna of the radio is rigged so it is possible to moving out the antenna and align easily with just one Bone.
http://www.youtube.com/watch?v=3Y_a-PmhpzE
Timelapse Video: https://www.youtube.com/watch?v=1Ugtf3UyXQc


If you wanna use this model for non commercial projects so check this link:
https://www.cgtrader.com/free-3d-models/electronics/audio/a-small-radio-high-poly


Sketchfab 3d-Preview: https://sketchfab.com/models/8aecb009d5e9424cb9c63b5137725f16

Low-Poly-Chair-Set Unitypackage :  https://www.youtube.com/watch?v=L0-VLNBeJwg&feature=youtu.be
Low-Poly-Chair-Set Unreal 4 Zip:  https://www.youtube.com/watch?v=hf7-clXKllo&feature=youtu.be

� DennisH2010

Sketchfab.com: https://sketchfab.com/dennish2010/recent

Verold.com: http://studio.verold.com/users/53199fa416c3570200000603/filter/mine

Blog : http://3dartdh.wordpress.com/

YouTube-Channel: https://www.youtube.com/user/DennisH2010